/*****************************************************************************/
/*        (c) IBM corporation (1999, 2008), ALL RIGHTS RESERVED              */
/*****************************************************************************/

public class Float_ {
   private float value;
   private final Object lock = new Object();

   public Float_(float initValue) {
      value = initValue;
   }

   public void set(float newValue) {
      synchronized(lock) {
         value = newValue;
      }
   }

   public float get() {
      synchronized(lock) {
         return value;
      }
   }

   public void addInt_bug(Integer_ anInt) {
      synchronized(lock) {
         value += anInt.get();
      }
   }

   public void addInt_nobug(Integer_ anInt) {
      synchronized(Integer_.getGateLock()) {
         synchronized(lock) {
            value += anInt.get();
         }
      }
   }
}