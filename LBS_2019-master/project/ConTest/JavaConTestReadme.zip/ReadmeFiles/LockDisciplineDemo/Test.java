/*****************************************************************************/
/*        (c) IBM corporation (1999, 2008), ALL RIGHTS RESERVED              */
/*****************************************************************************/

public class Test {
   public static void main(String[] args) {
      if (args.length != 1) {
         System.out.println("usage: Test [n]");
      }
      int testNum = Integer.parseInt(args[0]);
      Integer_ i1 = new Integer_(1);
      Integer_ i2 = new Integer_(2);
      Float_ f = new Float_(3.4f);

      i1.set(5);
      i2.set(6);
      f.set(7.8f);

      switch(testNum) {
         case 0:
            i1.setRound_bug(f);
            break;
         case 1:
            f.addInt_bug(i1);
            break;
         case 2:
            i1.setRound_nobug(f);
            f.addInt_nobug(i1);
            break;
         case 3:
            i1.add_bug(i2);
            break;
         case 4:
            i1.add_nobug(i2);
            break;
         case 5:
            i2.setRound_nobug(f); //to test class unions, have in one run all uses of the gate lock
            i2.add_nobug(i1);
            break;
         case 6:
            Test test = new Test();
            test.runDeadlock(i1, f);   
            break;
         default:
            throw new IllegalArgumentException("argument too big");
      }
   }
   
   public class IntThread extends Thread {
      Integer_ in;
      Float_ fl;
      public IntThread(Integer_ i, Float_ f) {
         in = i;
         fl = f;
      }
      public void run() {
         in.setRound_bug(fl);
      }
   }
   
   public class FloatThread extends Thread {
      Integer_ in;
      Float_ fl;
      public FloatThread(Integer_ i, Float_ f) {
         in = i;
         fl = f;
      }
      public void run() {
         fl.addInt_bug(in);
      }
   }
   
   private void runDeadlock(Integer_ i, Float_ f) {
      Thread intt = new Test.IntThread(i, f);
      Thread floatt = new Test.FloatThread(i, f);
      intt.start();
      floatt.start();
   }
   
}
