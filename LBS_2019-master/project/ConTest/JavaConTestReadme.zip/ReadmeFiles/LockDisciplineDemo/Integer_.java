/*****************************************************************************/
/*        (c) IBM corporation (1999, 2008), ALL RIGHTS RESERVED              */
/*****************************************************************************/

public class Integer_ {
   private int value;
   private final Object lock = new Object();
   private final static Object gateLock = new Object();

   public Integer_(int initValue) {
      value = initValue;
   }

   public static Object getGateLock() {
      return gateLock;
   }

   public void set(int newValue) {
      synchronized(lock) {
         value = newValue;
      }
   }

   public float get() {
      synchronized(lock) {
         return value;
      }
   }

   public void add_bug(Integer_ other) {
      synchronized(lock) {
         synchronized(other.lock) {
            value += other.value;
         }
      }
   }

   public void add_nobug(Integer_ other) {
      synchronized(gateLock) {
         synchronized(lock) {
            synchronized(other.lock) {
               value += other.value;
            }
         }
      }
   }

   public void setRound_bug(Float_ aFloat) {
      synchronized(lock) {
         value = (int)aFloat.get();
      }
   }

   public void setRound_nobug(Float_ aFloat) {
      synchronized(gateLock) {
         synchronized(lock) {
            value = (int)aFloat.get();
         }
      }
   }
}