/*****************************************************************************/
/*        (c) IBM corporation (1999, 2007), ALL RIGHTS RESERVED              */
/*****************************************************************************/

import java.io.*;
import com.ibm.contest.runtime.*;

/** Calculates the total time which the program under test spent trying to obtain locks, and in
wait. This is done by taking the time before and after each operation, subtracting, and adding to
the total. This is of course an overapproximation, as the listeners are called <i>some time</i>
before and after the measured operation - between them there could be event by this thread (other
listeners), by other threads (if there is a thread swich), and by other processed in the system.
Whenever a thread dies, the
total is printed to a file. This is not meant to be very useful, just to demonstrate some aspects of
using ConTest listeners.
<p>
Algorithm: We rely on the fact that each thread performs a sequence of before-after events,
such that each <i>after</i> corresponds to the previous <i>before</i>. In <i>before</i> we set the
current time to a thread-local variable, and in <i>after</i> we subtract the current time from the
variable, and this is the duration of the operation that just ended. Generally,
<code>java.lang.ThreadLocal</code> is a great friend of listeners, and you should be familiar with
it when writing listeners.
<p>
What about the danger of missing calls to <i>after</i> (say, in case a monitor-enter threw an
exception)? This takes care of itself: the current time will remain "orphaned" in this thread's
variable until the next event. The next event will be a <i>before</i>, and then the value will just
be overwritten. So the failing event will just not be counted, and this is what we want, since it
wasn't a "real" monitor-enter or wait. <i>wait</i> can take an <code>InterruptedException</code>
after waiting for some time, but we do get the <i>after</i> after that, so we will count it.
<p>
<li> Note: the file is flushed after each print, and is never closed explicitly (since we don't want
to be dependant upon the target program termination).</li>
</ul> */
public class SynchWaitTimeCounter implements BeforeMonitorEnterListener, AfterMonitorEnterListener,
      BeforeWaitListener, AfterWaitListener, ThreadEndListener {

   private final Object lock = new Object();
   private final BufferedWriter file;
   private long totalTimeMillis = 0;

   /* The time before each wait/monitor-enter, as returned from System.currentTimeMillis() is
   recorded in a thread-local variable. */
   private ThreadLocal<Long> beforeOperationTime = new ThreadLocal<Long>() {
      protected Long initialValue() {
         return 0L;
      }
   };

   public SynchWaitTimeCounter() throws IOException {
      file = new BufferedWriter(new FileWriter("synchWaitOut.txt"));
   }

   public void beforeMonitorEnterEvent(String programLocation, Object lock) {
      sharedBefore();
   }

   public void afterMonitorEnterEvent(String programLocation, Object lock) {
      sharedAfter();
   }

   public void beforeWaitEvent(String programLocation, Object lock, long timeout, int nanos) {
      sharedBefore();
   }

   public void afterWaitEvent(String programLocation, Object lock, long timeout, int nanos,
         Exception exception) {
      sharedAfter();
   }

   private void sharedBefore() {
      beforeOperationTime.set(System.currentTimeMillis());
   }

   private void sharedAfter() {
      long lastDuration = System.currentTimeMillis() - beforeOperationTime.get();
      synchronized(lock) {
         totalTimeMillis += lastDuration;
      }
   }

   public void threadEndEvent() {
      try {
         synchronized(lock) {
            file.write("current total time: " + totalTimeMillis);
            file.newLine();
            file.flush();
         }
      } catch (IOException e) {
         //ignore. See listener package documentation about the limited choice we have here.
      }
   }
}
