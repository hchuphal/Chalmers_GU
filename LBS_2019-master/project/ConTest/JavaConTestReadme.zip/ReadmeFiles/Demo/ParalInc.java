/*********************************************************/
/* (C) IBM Corporation (1999, 2009), ALL RIGHTS RESERVED */
/*********************************************************/
// See html doc for a description of this program.

public class ParalInc {

   private final static int NUM = 5;

   private static int i=0;

   private static class Incrementor extends Thread {
      public void run() {
         //synchronized(ParalInc.class) {
            i++;
         //}
      }
   }

   public static void main(String[] args) throws InterruptedException {
      Incrementor[] incrementors = new Incrementor[NUM];
      for (int i=0; i<NUM; i++) {
         incrementors[i] = new Incrementor();
      }
      for (Incrementor inc : incrementors) {
         inc.start();
      }
      for (Incrementor inc : incrementors) {
         inc.join();
      }
      System.out.println("final value: " + i);
      if (i != NUM) {
         System.err.println("   Bug - expected " + NUM);
      }
   }
}
