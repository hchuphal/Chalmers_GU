/*********************************************************/
/* (C) IBM Corporation (1999, 2005), ALL RIGHTS RESERVED */
/*********************************************************/
// See html doc for a description of this program.

import java.net.*;
import java.io.*;

public class SimpleGetter {
   /**
    * args[0] = local port to bind to
   */
   public static void main(String[] args) throws IOException {
      if (args.length != 1) {
         System.out.println("usage: SimpleGetter port");
         return;
      }
      General.addListener();
      int port = Integer.parseInt(args[0]);
      DatagramSocket soc = new DatagramSocket(port);
      soc.setSoTimeout(10000);
      byte[] buf = new byte[General.MAX_LENGTH];
      System.out.println("listening...");
      DatagramPacket pack = new DatagramPacket(buf, General.MAX_LENGTH);
      for (int i = 0; ; i++) {
         pack.setLength(General.MAX_LENGTH);
         try {
            soc.receive(pack);
            String msg = new String(pack.getData(), 0, pack.getLength());
            if (msg.equals(General.FINISH_CODE)) {
               System.out.println("finishing");
               return;
            }
            else {
               System.out.println(msg);
            }
         }
         catch (Exception e) {
            System.out.println("exception: " + e.getClass().getName() + ' ' + e.getMessage());
         }
      }
   }
}