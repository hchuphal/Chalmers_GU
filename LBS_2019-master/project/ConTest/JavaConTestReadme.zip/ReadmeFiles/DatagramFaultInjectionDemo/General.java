/*********************************************************/
/* (C) IBM Corporation (1999, 2005), ALL RIGHTS RESERVED */
/*********************************************************/
// See html doc for a description of this program.

import com.ibm.contest.test_ui.DatagramFaultInjectionInterface;

public class General {
   public final static int MAX_LENGTH = 100;
   public final static String FINISH_CODE = "end";
   public final static byte[] FINISH_CODE_B = FINISH_CODE.getBytes();
   public final static int FINISH_CODE_LENGTH = FINISH_CODE_B.length;


   /**
    *assign the finish code to the given buffer (so that client can send it in a datagram packet). Client should consult
    *SimpleGetter.FINISH_CODE_LENGTH to know how many bytes were assigned, and the minimum size of 'buf'.
    *@exception ArrayIndexOutOfBoundsException if 'buf' is shorter than FINISH_CODE_LENGTH.
   */
   public static void getFinishCode(byte[] buf) {
      for (int i=0; i<FINISH_CODE_LENGTH; i++) {
         buf[i] = FINISH_CODE_B[i];
      }
   }

   static class Listener implements DatagramFaultInjectionInterface.StateChangeListener {
      public void stateChanged(DatagramFaultInjectionInterface.StateChangeEvent e) {
         System.out.println("state change report: " + e);
      }
   }

   static void addListener() {
      DatagramFaultInjectionInterface.addStateChangeListener(new Listener());
   }
}