/*********************************************************/
/* (C) IBM Corporation (1999, 2005), ALL RIGHTS RESERVED */
/*********************************************************/
// See html doc for a description of this program.

import java.net.*;
import java.io.*;
import com.ibm.contest.test_ui.DatagramFaultInjectionInterface;

public class SequenceSender {
   /**
    * args[0] = address to send to.
    * args[1] = port to send to
    * args[2] = delay in millis between packets
   */
   public static void main(String[] args) throws IOException, InterruptedException {
      if (args.length != 3) {
         System.out.println("usage: SequenceSender address port delay");
         return;
      }
      General.addListener();
      InetAddress addr = InetAddress.getByName(args[0]);
      int port = Integer.parseInt(args[1]);
      int delay = Integer.parseInt(args[2]);
      DatagramSocket soc = new DatagramSocket();
      int LENGTH = 10;
      byte[] buf = new byte[LENGTH];
      DatagramPacket pack = new DatagramPacket(buf, LENGTH, addr, port);
      for (int i =0; i<100; i++) {
         String numS = Integer.toString(i);
         byte[] numB = numS.getBytes();
         int len = numB.length;
         for (int j=0; j<len; j++) {
            buf[j] = numB[j]; //throw ArrayIndexOutOfBoundsException if LENGTH is not big enough
         }
         pack.setLength(len);
         soc.send(pack);
         System.out.println("sent: " + numS);
         Thread.sleep(delay);
      }
      DatagramFaultInjectionInterface.setMode(DatagramFaultInjectionInterface.MODE_NO_NOISE);
      General.getFinishCode(buf);
      pack.setLength(General.FINISH_CODE_LENGTH);
      soc.send(pack);
      soc.send(pack);
      soc.send(pack);
      System.out.println("done");
   }
}