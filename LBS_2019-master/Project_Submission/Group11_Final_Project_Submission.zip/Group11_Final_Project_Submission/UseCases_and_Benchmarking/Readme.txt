?: indicates that the tool was able to detect the race in a vulnarbale program / not detect anything in a fixed race program
?: indicates that the tool did not detect the race in a vulnarbale program / still detect a race in a fixed race program
No Result: indicates that the tool gives no result at all