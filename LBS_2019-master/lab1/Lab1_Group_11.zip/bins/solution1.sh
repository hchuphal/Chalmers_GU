#!/bin/bash
echo "Running Solution of part 1 of Assignemnt 1"

java -jar "solution1.jar"
