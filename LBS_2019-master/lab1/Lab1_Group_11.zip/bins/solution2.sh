#!/bin/bash
echo "Running Solution of part 2 of Assignemnt 1"

java -jar "solution2.jar"
