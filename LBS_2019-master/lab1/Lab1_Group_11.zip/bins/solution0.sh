#!/bin/bash
echo "Running Solution of part 0 of Assignemnt 1"

java -jar "solution0.jar"
