/**
 */
package manufacturingSystem;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quality Assurance</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see manufacturingSystem.ManufacturingSystemPackage#getQualityAssurance()
 * @model
 * @generated
 */
public interface QualityAssurance extends EachStep {
} // QualityAssurance
