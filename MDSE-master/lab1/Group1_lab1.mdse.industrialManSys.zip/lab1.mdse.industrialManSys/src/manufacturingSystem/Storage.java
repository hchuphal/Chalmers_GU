/**
 */
package manufacturingSystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Storage</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see manufacturingSystem.ManufacturingSystemPackage#getStorage()
 * @model
 * @generated
 */
public interface Storage extends EObject {
} // Storage
