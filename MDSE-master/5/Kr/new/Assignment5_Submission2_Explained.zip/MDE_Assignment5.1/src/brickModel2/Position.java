/**
 */
package brickModel2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Position</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link brickModel2.Position#getCoordinates <em>Coordinates</em>}</li>
 * </ul>
 *
 * @see brickModel2.BrickModel2Package#getPosition()
 * @model
 * @generated
 */
public interface Position extends EObject {
	/**
	 * Returns the value of the '<em><b>Coordinates</b></em>' attribute.
	 * The literals are from the enumeration {@link brickModel2.BrickPosition}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Coordinates</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Coordinates</em>' attribute.
	 * @see brickModel2.BrickPosition
	 * @see #setCoordinates(BrickPosition)
	 * @see brickModel2.BrickModel2Package#getPosition_Coordinates()
	 * @model
	 * @generated
	 */
	BrickPosition getCoordinates();

	/**
	 * Sets the value of the '{@link brickModel2.Position#getCoordinates <em>Coordinates</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Coordinates</em>' attribute.
	 * @see brickModel2.BrickPosition
	 * @see #getCoordinates()
	 * @generated
	 */
	void setCoordinates(BrickPosition value);

} // Position
