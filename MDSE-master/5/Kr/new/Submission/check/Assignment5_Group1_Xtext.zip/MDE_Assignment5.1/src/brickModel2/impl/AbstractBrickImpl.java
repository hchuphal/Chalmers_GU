/**
 */
package brickModel2.impl;

import brickModel2.AbstractBrick;
import brickModel2.BrickModel2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Brick</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AbstractBrickImpl extends BrickElementImpl implements AbstractBrick {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractBrickImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BrickModel2Package.Literals.ABSTRACT_BRICK;
	}

} //AbstractBrickImpl
