/**
 */
package brickModel2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Brick</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see brickModel2.BrickModel2Package#getAbstractBrick()
 * @model
 * @generated
 */
public interface AbstractBrick extends BrickElement {
} // AbstractBrick
