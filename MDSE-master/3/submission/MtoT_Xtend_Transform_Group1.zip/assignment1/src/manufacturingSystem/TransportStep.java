/**
 */
package manufacturingSystem;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transport Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see manufacturingSystem.ManufacturingSystemPackage#getTransportStep()
 * @model
 * @generated
 */
public interface TransportStep extends Step {
} // TransportStep
