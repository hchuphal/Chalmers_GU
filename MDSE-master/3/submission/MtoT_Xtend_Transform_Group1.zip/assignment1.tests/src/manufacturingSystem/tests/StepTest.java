/**
 */
package manufacturingSystem.tests;

import manufacturingSystem.Step;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Step</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class StepTest extends ManufacturingSystemElementTest {

	/**
	 * Constructs a new Step test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StepTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Step test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Step getFixture() {
		return (Step)fixture;
	}

} //StepTest
